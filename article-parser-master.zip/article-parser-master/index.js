/**
 * Starting app
 * @ndaidong
**/
let main = require('./src/main');
main.version = require('./package').version;

module.exports = main;
